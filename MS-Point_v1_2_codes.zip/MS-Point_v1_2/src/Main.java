import DataPreprocessing.a_TxtCombiner;
import DataPreprocessing.b_TrainingDataset;
import LogisticRegression.Score;
import Output.CsvToTxtSplitter;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        //param
        String k_foldStr = args[0];
        String inputTxtDir = args[1];
        String outputDir = args[2];

        int k_fold = 5;

        // 處理輸入invalid
        long startTime = System.currentTimeMillis();
        try {
            k_fold = Integer.parseInt(k_foldStr.trim());
        } catch (NumberFormatException e) {
            System.out.println("Warn: You entered an invalid integer. The analysis will proceed with the default value (k=5).");
            e.printStackTrace();
        }

        if (inputTxtDir.isEmpty() || outputDir.isEmpty()) {
            System.out.println("Error: Please enter input and output directories.");
            return;
        }




        // --input folder
        File inputFolder = new File(inputTxtDir);
        File[] txtFiles = inputFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
        if (txtFiles == null || txtFiles.length == 0) {
            System.out.println("There are no txt files in the input folder.");
            return;
        }
        // --output folder
        File outputFolder = new File(outputDir);
        if (!outputFolder.exists()) {
            outputFolder.mkdirs();
        }

        String combinedCsvFile = outputDir + "/data_combined.csv";
        String trainingDataCsvFile = outputDir + "/data_for_train.csv";
        String resultCombinedCsvFile = outputDir + "/result_combined.csv";

        a_TxtCombiner combiner = new a_TxtCombiner();
        b_TrainingDataset trainingDataset = new b_TrainingDataset();
        Score score = new Score();
        CsvToTxtSplitter csvToTxtSplitter = new CsvToTxtSplitter();

        try {
            System.out.println("=========================================== Go! ==============================================");
            System.out.println("    input  : " + inputTxtDir );
            System.out.println("    output : " + outputDir );
            System.out.println("==============================================================================================\n");

            combiner.combineTxtFiles(inputTxtDir, combinedCsvFile);
            System.out.println("------------------ txt combination finished------------------>");

            Map<String, Integer> frequencyMap = trainingDataset.buildTrainingDataset(combinedCsvFile, trainingDataCsvFile);

            double[] means_feature = trainingDataset.getMeans_feature();
            double[] standards_feature = trainingDataset.getStandards_feature();

            // Display frequency table
            System.out.println("Frequency Table : ");
            for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
            System.out.println("------------------ build training dataset finished------------------>");

            // Build model and predict
            score.build_output(trainingDataCsvFile, combinedCsvFile, resultCombinedCsvFile, k_fold, means_feature, standards_feature);
            System.out.println("---------------build model and prediction finished--------------->\n");

            csvToTxtSplitter.Split(resultCombinedCsvFile, outputDir);
            System.out.println("-----------------------split csv to txt(s) finished---------------------->\n");

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("An error occurred: " + e.getMessage() );
        }

        long endTime = System.currentTimeMillis();
        long runtime = endTime - startTime;
        System.out.println(String.format("=================================== Finished! (Runtime: %.2f seconds) ===================================", runtime / 1000.0));
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
    }
}
