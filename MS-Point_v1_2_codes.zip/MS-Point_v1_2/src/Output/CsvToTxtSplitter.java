package Output;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CsvToTxtSplitter {
    public void Split(String resultCombinedCsvFile, String outputDir) {
        String line;
        String csvSplitBy = ",";


        File directory = new File(outputDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        Map<String, StringBuilder> fileContents = new HashMap<>();
        String headerLine = null;

        try (BufferedReader br = new BufferedReader(new FileReader(resultCombinedCsvFile))) {
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                // column name
                if (isFirstLine) {
                    headerLine = line;
                    isFirstLine = false;
                    continue;
                }

                String[] columns = line.split(csvSplitBy, 2);

                if (columns.length < 2) {
                    System.out.println("Invalid line: " + line);
                    continue;
                }

                String fileName = columns[0].replaceAll("[\\\\/:*?\"<>|]", "");
                String content = columns[1];


                fileContents.computeIfAbsent(fileName, k -> new StringBuilder())
                        .append(convertToDouble(content, csvSplitBy))
                        .append(System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (headerLine != null) {
            String[] headerColumns = headerLine.split(csvSplitBy, 2);
            String processedHeaderLine = headerColumns.length > 1 ? headerColumns[1].replace(csvSplitBy, "\t") : "";


            for (Map.Entry<String, StringBuilder> entry : fileContents.entrySet()) {
                String filePath = outputDir + "/" + entry.getKey();
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
                    bw.write(processedHeaderLine);
                    bw.newLine();
                    bw.write(entry.getValue().toString());
                } catch (IOException e) {
                    System.out.println("Error writing to file: " + filePath);
                    e.printStackTrace();
                }
            }
        }
    }

    private String convertToDouble(String content, String csvSplitBy) {
        StringBuilder sb = new StringBuilder();
        String[] values = content.split(csvSplitBy);
        for (String value : values) {
            try {

                value = value.replace("\"", "");
                double doubleValue = Double.parseDouble(value);
                sb.append(doubleValue).append("\t");
            } catch (NumberFormatException e) {
                e.printStackTrace();
                sb.append(value).append("\t"); // 如果轉不了
            }
        }
        // 最後一個
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb.toString();
    }

}
