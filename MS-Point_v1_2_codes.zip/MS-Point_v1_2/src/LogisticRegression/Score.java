
package LogisticRegression;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;


import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import weka.core.converters.CSVLoader;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Standardize;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.NumericToNominal;
import weka.classifiers.functions.Logistic;

import java.io.File;
import weka.classifiers.Evaluation;
import java.util.Random;

public class Score {

    // 9個指標所在的位置（根據MS-PICKER）
    private final int[] FEATURE_INDICES = {11, 12, 13, 14, 15, 16, 17, 18, 19};
    private String[] features = {"Shapiro-Wilk value", "Slope", "ZigZagIndex", "Symmetry", "Sharpness", "TPASR", "ApexMaxBoundary", "SignificanceLevel", "SNR"};
    private double[] coefficients = new double[10];



    public void build_output(String trainingDataCsvFile, String combinedCsvFile, String resultCombinedCsvFile, int k_fold, double[] means_feature, double[] standards_feature) {
        ArrayList<String[]> outputData = new ArrayList<>();
        try {
            // load
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File(trainingDataCsvFile));
            Instances dataset = loader.getDataSet();

            Remove remove = new Remove();
            remove.setAttributeIndices("1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30");
            remove.setInputFormat(dataset);
            Instances newData = Filter.useFilter(dataset, remove);
            System.out.println("Raw Data: ");
            System.out.println(newData.toSummaryString());

            // Set the first column as the class index
            newData.setClassIndex(0);

            NumericToNominal convertNominal = new NumericToNominal();
            convertNominal.setAttributeIndices("1");
            convertNominal.setInputFormat(newData);
            Instances finalData = Filter.useFilter(newData, convertNominal);


            if (finalData.classAttribute().isNumeric()) {
                throw new RuntimeException("Class attribute is numeric, but logistic regression requires categorical classes.");
            }

            System.out.println("Final Data: ");
            System.out.println(finalData.toSummaryString());
            int classIndex = finalData.classIndex();
            String[] classLabels = new String[finalData.numClasses()];
            for (int i = 0; i < finalData.numClasses(); i++) {
                classLabels[i] = finalData.classAttribute().value(i);
            }
            System.out.println("Class Index: " + classIndex);
            System.out.println("Class labels: " + Arrays.toString(classLabels));



            // cross-validation
            Logistic logistic_cv = new Logistic();
            Evaluation evaluation_cv = new Evaluation(finalData);
            int folds = k_fold;  // fold
            evaluation_cv.crossValidateModel(logistic_cv, finalData, folds, new Random(42));
            double accuracy_cv = evaluation_cv.pctCorrect();
            double auc_cv = evaluation_cv.areaUnderROC(0);

            System.out.println("Logistic Regression Cross-Validation Average Accuracy :" + accuracy_cv);
            System.out.println("Logistic Regression Cross-Validation Average AUC :" + auc_cv);


            Logistic logistic = new Logistic();
            logistic.buildClassifier(finalData);
//            Evaluation evaluation = new Evaluation(finalData);
//            evaluation.evaluateModel(logistic, finalData);
//            double accuracy = evaluation.pctCorrect();
//            double auc = evaluation.areaUnderROC(0);
//            System.out.println("Logistic Regression Testing Average Accuracy :" + accuracy);
//            System.out.println("Logistic Regression Testing Average AUC :" + auc);



            // coefficient
            double[][] coefficients_2 = logistic.coefficients();

            for (int i = 0; i < coefficients_2.length; i++) {
                for (int j = 0; j < coefficients_2[i].length; j++) {
                    this.coefficients[i] = coefficients_2[i][j];
                }
            }

            System.out.println("Logistic Regression Coefficients:");
            System.out.println("Intercept: " + coefficients[0]);
            for (int i = 0; i < coefficients.length-1; i++) {
                System.out.print(features[i] + ": " + coefficients[i+1]);
                System.out.println();
            }

            // calculate score
            double[][] newPredictData = readData(combinedCsvFile, FEATURE_INDICES);
            standardize(newPredictData, means_feature, standards_feature);
            fillMissingValuesWithZero(newPredictData);

            List<String[]> originalData = readOriginalCSV(combinedCsvFile);
            String[] header = new String[originalData.get(0).length + 1];
            System.arraycopy(originalData.get(0), 0, header, 0, originalData.get(0).length);
            header[header.length - 1] = "quality_score";
            outputData.add(header);

            for (int i = 0; i < newPredictData.length; i++) {
                String[] row = new String[originalData.get(i + 1).length + 1];
                System.arraycopy(originalData.get(i + 1), 0, row, 0, originalData.get(i + 1).length);
                try {
                    double logit = coefficients[0];
                    for(int j = 0; j < newPredictData[i].length; j++){
                        logit += newPredictData[i][j] * coefficients[j+1];
                    }
                    double probability =  1.0 / (1.0 + Math.exp(-logit));//probability of -1
                    double quality_score = 1 - probability * 2;
                    row[row.length - 1] = String.valueOf(quality_score);
                } catch (Exception e) {
                    e.printStackTrace();
                    row[row.length - 1] = "NaN";
                }
                outputData.add(row);
            }

            writeCSV(resultCombinedCsvFile, outputData);


        } catch (IOException | CsvException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    private double[][] readData(String filePath, int[] featureIndices) throws IOException, CsvException {
        List<double[]> dataList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            reader.readNext(); // skip title
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                double[] row = new double[featureIndices.length];
                for (int i = 0; i < featureIndices.length; i++) {
                    try {
                        row[i] = Double.parseDouble(nextLine[featureIndices[i]]);
                    } catch (NumberFormatException e) {
                        row[i] = Double.NaN;
                    }
                }
                dataList.add(row);
            }
        }
        return dataList.toArray(new double[0][0]);
    }

    private List<String[]> readOriginalCSV(String filePath) throws IOException, CsvException {
        List<String[]> dataList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                dataList.add(nextLine);
            }
        }
        return dataList;
    }

    private void standardize(double[][] data, double[] means, double[] stdDevs) {
        for (double[] row : data) {
            for (int i = 0; i < row.length; i++) {
                row[i] = (row[i] - means[i]) / stdDevs[i];
            }
        }
    }

    private void fillMissingValuesWithZero(double[][] data) {
        for (double[] row : data) {
            for (int i = 0; i < row.length; i++) {
                if (Double.isNaN(row[i])) {
                    row[i] = 0;
                }
            }
        }
    }

    private void writeCSV(String filePath, List<String[]> data) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            for (String[] row : data) {
                writer.writeNext(row);
            }
        }
    }
}
