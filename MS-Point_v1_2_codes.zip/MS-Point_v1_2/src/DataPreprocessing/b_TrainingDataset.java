package DataPreprocessing;

import tech.tablesaw.api.Table;
import tech.tablesaw.api.DoubleColumn;
import tech.tablesaw.api.StringColumn;
import tech.tablesaw.selection.Selection;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;

public class b_TrainingDataset {

    private double[] means_feature = new double[9] ;
    private double[] standards_feature = new double[9] ;
    private String[] features = {"Shapiro-Wilk value", "Slope", "ZigZagIndex", "Symmetry", "Sharpness", "TPASR", "ApexMaxBoundary", "SignificanceLevel", "SNR"};

    public double[] getMeans_feature() {
        return means_feature;
    }

    public double[] getStandards_feature() {
        return standards_feature;
    }

    public Map<String, Integer> buildTrainingDataset(String combinedCsvFile, String trainingDataCsvFile) {
        try {

            Table totData = Table.read().csv(combinedCsvFile);

            // (Charge == 1)
            Table filteredData = totData.where(totData.numberColumn("Charge").isEqualTo(1));

            filteredData = removeRowsWithNa(filteredData, new String[]{
                    "Slope", "ZigZagIndex", "Symmetry", "Sharpness", "TPASR", "ApexMaxBoundary", "SignificanceLevel", "SNR", "Shapiro-Wilk value", "RT(Sec)", "Charge"
            });

            // calculate the medium
            double sharpnessMedian = filteredData.doubleColumn("Sharpness").median();
            double significanceMedian = filteredData.doubleColumn("SignificanceLevel").median();
            double slopeMedian = filteredData.doubleColumn("Slope").median();
            double symmetryMedian = filteredData.doubleColumn("Symmetry").median();
            double tpasrRMedian = filteredData.doubleColumn("TPASR").median();
            double zzMedian = filteredData.doubleColumn("ZigZagIndex").median();
            double ambMedian = filteredData.doubleColumn("ApexMaxBoundary").median();


            DoubleColumn vsharpness = filteredData.doubleColumn("Sharpness").map(d -> d >= sharpnessMedian ? 1.0 : 0.0);
            vsharpness.setName("vsharpness");
            filteredData.addColumns(vsharpness);

            DoubleColumn vsignificance = filteredData.doubleColumn("SignificanceLevel").map(d -> d >= significanceMedian ? 1.0 : 0.0);
            vsignificance.setName("vsignificance");
            filteredData.addColumns(vsignificance);

            DoubleColumn vslope = filteredData.doubleColumn("Slope").map(d -> d >= slopeMedian ? 1.0 : 0.0);
            vslope.setName("vslope");
            filteredData.addColumns(vslope);

            DoubleColumn vsnr = filteredData.doubleColumn("SNR").map(d -> d >= 3 ? 1.0 : 0.0);
            vsnr.setName("vsnr");
            filteredData.addColumns(vsnr);

            DoubleColumn vsymmetry = filteredData.doubleColumn("Symmetry").map(d -> d >= symmetryMedian ? 1.0 : 0.0);
            vsymmetry.setName("vsymmetry");
            filteredData.addColumns(vsymmetry);

            DoubleColumn vtpasr = filteredData.doubleColumn("TPASR").map(d -> d <= tpasrRMedian ? 1.0 : 0.0);
            vtpasr.setName("vtpasr");
            filteredData.addColumns(vtpasr);

            DoubleColumn vzz = filteredData.doubleColumn("ZigZagIndex").map(d -> d <= zzMedian ? 1.0 : 0.0);
            vzz.setName("vzz");
            filteredData.addColumns(vzz);

            DoubleColumn vsw = filteredData.doubleColumn("Shapiro-Wilk value").map(d -> d <= 0.05 ? 1.0 : 0.0);
            vsw.setName("vsw");
            filteredData.addColumns(vsw);

            DoubleColumn vamb = filteredData.doubleColumn("ApexMaxBoundary").map(d -> d <= ambMedian ? 1.0 : 0.0);
            vamb.setName("vamb");
            filteredData.addColumns(vamb);

            // calculate the score and classify
            DoubleColumn vote = filteredData.doubleColumn("vsharpness").add(filteredData.doubleColumn("vsignificance"))
                    .add(filteredData.doubleColumn("vslope")).add(filteredData.doubleColumn("vsnr"))
                    .add(filteredData.doubleColumn("vsymmetry")).add(filteredData.doubleColumn("vtpasr"))
                    .add(filteredData.doubleColumn("vzz")).add(filteredData.doubleColumn("vsw"))
                    .add(filteredData.doubleColumn("vamb"));
            vote.setName("vote");
            filteredData.addColumns(vote);

            StringColumn quality = StringColumn.create("quality", filteredData.rowCount());
            for (int i = 0; i < filteredData.rowCount(); i++) {
                double voteValue = vote.getDouble(i);
                if (voteValue >= 6) {
                    quality.set(i, "1");
                } else if (voteValue <= 3) {
                    quality.set(i, "-1");
                } else {
                    quality.set(i, "0");
                }
            }
            filteredData.addColumns(quality);

            // 1,-1
            Table finalData = filteredData.where(filteredData.stringColumn("quality").isEqualTo("1")
                    .or(filteredData.stringColumn("quality").isEqualTo("-1")));

            for(int i=0;i< features.length;i++){
                String colum = features[i];
                means_feature[i] = finalData.doubleColumn(colum).mean();
                standards_feature[i] = finalData.doubleColumn(colum).standardDeviation();
            }

            // Standardize
            DoubleColumn sw_s = finalData.doubleColumn("Shapiro-Wilk value").map(d -> (d - means_feature[0]) / standards_feature[0]);
            sw_s.setName("Shapiro-Wilk value_s");
            finalData.addColumns(sw_s);

            DoubleColumn slope_s = finalData.doubleColumn("Slope").map(d -> (d - means_feature[1]) / standards_feature[1]);
            slope_s.setName("Slope_s");
            finalData.addColumns(slope_s);

            DoubleColumn zigzag_s = finalData.doubleColumn("ZigZagIndex").map(d -> (d - means_feature[2]) / standards_feature[2]);
            zigzag_s.setName("ZigZagIndex_s");
            finalData.addColumns(zigzag_s);

            DoubleColumn symmetry_s = finalData.doubleColumn("Symmetry").map(d -> (d - means_feature[3]) / standards_feature[3]);
            symmetry_s.setName("Symmetry_s");
            finalData.addColumns(symmetry_s);

            DoubleColumn sharpness_s = finalData.doubleColumn("Sharpness").map(d -> (d - means_feature[4]) / standards_feature[4]);
            sharpness_s.setName("Sharpness_s");
            finalData.addColumns(sharpness_s);

            DoubleColumn tpasr_s = finalData.doubleColumn("TPASR").map(d -> (d - means_feature[5]) / standards_feature[5]);
            tpasr_s.setName("TPASR_s");
            finalData.addColumns(tpasr_s);

            DoubleColumn apexmax_s = finalData.doubleColumn("ApexMaxBoundary").map(d -> (d - means_feature[6]) / standards_feature[6]);
            apexmax_s.setName("ApexMaxBoundary_s");
            finalData.addColumns(apexmax_s);


            DoubleColumn significance_s = finalData.doubleColumn("SignificanceLevel").map(d -> (d - means_feature[7]) / standards_feature[7]);
            significance_s.setName("SignificanceLevel_s");
            finalData.addColumns(significance_s);

            DoubleColumn snr_s = finalData.doubleColumn("SNR").map(d -> (d - means_feature[8]) / standards_feature[8]);
            snr_s.setName("SNR_s");
            finalData.addColumns(snr_s);


            // undersample
            finalData = undersample(finalData, "quality");

            finalData.write().csv(trainingDataCsvFile);

            Map<String, Integer> frequencyMap = calculateFrequencyTable(finalData, "quality");


            return frequencyMap;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Table removeRowsWithNa(Table table, String[] columns) {
        Selection selection = table.numberColumn(columns[0]).isNotMissing();
        for (int i = 1; i < columns.length; i++) {
            selection = selection.and(table.numberColumn(columns[i]).isNotMissing());
        }
        return table.where(selection);
    }

    public Map<String, Integer> calculateFrequencyTable(Table table, String columnName) {
        StringColumn qualityColumn = table.stringColumn(columnName);
        Map<String, Integer> frequencyMap = new HashMap<>();

        for (String value : qualityColumn) {
            frequencyMap.put(value, frequencyMap.getOrDefault(value, 0) + 1);
        }
        return frequencyMap;
    }

    private Table undersample(Table table, String labelColumn) {
        List<Integer> positiveIndices = new ArrayList<>();
        List<Integer> negativeIndices = new ArrayList<>();

        StringColumn labels = table.stringColumn(labelColumn);

        for (int i = 0; i < labels.size(); i++) {
            if (labels.get(i).equals("1")) {
                positiveIndices.add(i);
            } else if (labels.get(i).equals("-1")) {
                negativeIndices.add(i);
            }
        }

        Random rand = new Random();
        while (positiveIndices.size() > negativeIndices.size()) {
            positiveIndices.remove(rand.nextInt(positiveIndices.size()));
        }
        while (negativeIndices.size() > positiveIndices.size()) {
            negativeIndices.remove(rand.nextInt(negativeIndices.size()));
        }

        List<Integer> undersampledIndices = new ArrayList<>();
        undersampledIndices.addAll(positiveIndices);
        undersampledIndices.addAll(negativeIndices);

        return table.where(Selection.with(undersampledIndices.stream().mapToInt(i -> i).toArray()));
    }
}
