package DataPreprocessing;

import java.io.*;

public class a_TxtCombiner {

    public void combineTxtFiles(String inputTxtDir,String combinedCsvFile) throws IOException {

        File folder = new File(inputTxtDir);
        File[] txtFiles = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));

        if (txtFiles == null || txtFiles.length == 0) {
            throw new IllegalArgumentException("There are no txt files in the input folder.");
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(combinedCsvFile))) {
            boolean isFirstFile = true;
            for (File txtFile : txtFiles) {
                processSingleFile(writer, txtFile, isFirstFile);
                isFirstFile = false;
            }
        }
    }

    private void processSingleFile(BufferedWriter writer, File txtFile, boolean isFirstFile) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(txtFile))) {
            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                // column name
                if (isFirstLine) {
                    if (isFirstFile) {
                        writer.write("Filename," + line.replace("\t", ","));
                        writer.newLine();
                    }
                    isFirstLine = false;
                } else {
                    writer.write(txtFile.getName() + "," + line.replace("\t", ","));
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
